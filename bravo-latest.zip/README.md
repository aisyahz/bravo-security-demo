# Bravo Security Network Sdn. Bhd. — Website Preview

A responsive website built with HTML, CSS, vanilla JavaScript and a small PHP
contact-form handler. Services and Operations content are presented together
on the Services page; `operations.html` redirects legacy links to that section.
It is intended for staging and client review.
It has not been deployed and does not change the live WordPress installation.

## Project structure

```
Bravo/
├─ index.html              Home
├─ about.html              Company background, vision, mission and values
├─ services.html           Services overview, 12 services and operations panels
├─ operations.html         Redirect for legacy links to the merged section
├─ contact.php             Contact details and server-side enquiry form
├─ assets/
│  ├─ css/style.css        Shared layout and responsive styles
│  ├─ js/main.js           Navigation, header and small UI interactions
│  ├─ images/README.md     Image inventory and generation prompts
│  └─ img/
│     └─ bravo-security-logo.png   Official company logo
```

## Local preview

The contact form needs PHP and cannot run through a static-only server. With
PHP 7.4 or newer installed, open PowerShell in this directory and run:

```powershell
php -S localhost:5500
```

Then visit <http://localhost:5500>. The built-in PHP server is for local
testing only; do not expose it to the public internet.
`node dev-server.js` can preview the static pages only; it returns an explicit
PHP-required response for the contact form and does not execute PHP.

## Contact form and hosting setup

`contact.php` validates the form server-side, limits service choices to the
confirmed list, escapes redisplayed values, verifies a session CSRF token,
includes a honeypot, and rate-limits repeated submissions in the same session.
It uses PHP `mail()` to send enquiries to `general.bravonetwork@gmail.com`.
No mail credentials or API keys are stored in the website.

Before client review of the form on staging:

1. Confirm PHP sessions and outbound `mail()` are enabled on the hosting
   account.
2. Confirm `website@bravosecuritynetwork.com.my` is an authorized sender for
   the host's mail transport and configure the domain's email authentication
   (SPF/DKIM) as applicable.
3. Send test enquiries and verify both successful delivery and failure
   messages. Shared-host mail delivery has not been tested from this
   development environment. If the host requires authenticated SMTP, configure
   it through a host-supported mail service without putting credentials in
   public files.

## Verified business details used

- **Registered name:** Bravo Security Network Sdn. Bhd.
- **SSM:** 202001040772 (1397093-X)
- **Established:** 20 December 2020
- **Email:** general.bravonetwork@gmail.com
- **Address:** Tingkat 4, Blok G, Excella Business Park, Jalan Ampang Putra,
  Taman Ampang Hilir, 55100 Kuala Lumpur, Malaysia
- **Coverage:** Kuala Lumpur, Selangor, Peninsular Malaysia, Sabah and Sarawak

The pages do not show a KDN licence number or invented staffing, client or
achievement statistics. The licensing statement is based on the supplied
company profile and is not an independent verification of current status.

## Images and branding

The supplied transparent company logo is used in the header, footer and tab
icon. Theme colours follow the proposed values in the supplied brief and are
not represented as official colour specifications.

The approved desktop and mobile hero images, supplied Armed Guard and K9
images, and five newly supplied service/operations images are in
`assets/images/`. The desktop hero remains the approved IMG-01 image. Remaining
image needs and generation prompts are documented in
[assets/images/README.md](assets/images/README.md); the page uses branded
fallbacks until optional images are added. The hero loads eagerly, and other
image slots load lazily.

Supplied personnel imagery is illustrative and should not be represented as
documentary photographs of Bravo staff unless verified by the company. Update
image descriptions and gallery captions when approved company photography is
available.

The shared responsive stylesheet includes tablet/mobile navigation, safe-area
spacing, touch-friendly controls, restrained entrance animations and
`prefers-reduced-motion` support. Animations are progressive enhancement:
content remains visible if JavaScript or IntersectionObserver is unavailable.
The homepage opens immediately without a blocking welcome overlay. Hero and
scroll reveals run once; reduced-motion users receive a static presentation.

The Contact page and footer show the client-confirmed hotline
`+603 9226 9786` and email address. WhatsApp actions continue to use the
approved destination, while showing labels such as “Contact Us” and
“WhatsApp Us”. The fax is marked as awaiting client confirmation; no number is
displayed.

## cPanel ZIP upload

Create `Bravo-cPanel-Upload.zip` from the website files at the project root.
The archive should contain `index.html`, the other site pages, `contact.php`
and `assets/` directly at its root (not nested inside an extra project folder).
Exclude `.git`, local preview scripts and existing ZIP archives. In cPanel File
Manager, upload the archive into the intended document root or staging
directory, extract it there, and confirm the PHP form runs on the hosting
account. Keep a backup of the existing site before replacing any files.

## Staging and rollback

1. Back up the current WordPress files and database before any production
   changes.
2. Upload this project to a separate staging subdomain or directory configured
   to run PHP. Do not copy it over the live WordPress document root.
3. Test all five pages, navigation, contact links, form delivery, keyboard use,
   mobile layouts and hosting logs. Obtain client approval.
4. Do not replace the live site without explicit approval and a planned
   maintenance window.
5. To roll back a staging preview, remove or disable only the staging copy.
   For any later approved production replacement, restore the pre-change
   WordPress file/database backup using the hosting provider's documented
   procedure.

## Outstanding before launch

- Verify PHP mail transport and real-world email delivery on the hosting
  account.
- Supply and approve company photography or commissioned imagery.
- Review all supplied company facts and service descriptions before publishing.
- Configure and verify the staging domain, HTTPS and backups in cPanel.


## Local UX upgrade

The approved page structure, copy, logo, hero and WhatsApp destination are retained.
The supplied Kuala Lumpur skyline remains in both About sections. Images now use
optimized WebP derivatives; original PNG sources are retained. Local Lucide SVGs
are bundled in `assets/icons/lucide.svg`, with their license alongside them.
There is no runtime icon CDN or animation library.

Each service now has a quotation link that preselects its matching PHP form option.
The form progressively enhances native POST with inline validation and pending,
confirmed and failure states. Confirmation requires a server-side session flash
set only after `mail()` accepts the enquiry. A query string cannot forge success.
Mail acceptance does not establish final inbox delivery; verify the hosting mail
transport separately. No real enquiries were sent during local tests.

See [UX-REVIEW.md](UX-REVIEW.md) for findings, modified files and test coverage.
The existing `Bravo-cPanel-Upload.zip` predates these changes and was not rebuilt.
No production or WordPress changes have been made.

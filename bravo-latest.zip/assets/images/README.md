# Website image assets

The approved desktop hero (`hero-security.png`) and mobile hero
(`hero-security-mobile.png`) are already connected to the homepage and must not
be replaced. The official company logo is separate at `assets/img/` and must
not be recreated.

## Images currently in the project

- `hero-security.png` — approved desktop hero.
- `hero-security-mobile.png` — approved portrait hero for screens up to 720px.
- `about-team.png` — illustrative team image used in the homepage About section.
- `armed-guard.png` — supplied Armed Guard service image.
- `k9-security.png` — supplied K9 service image.
- `visitor-assistance.png` — supplied image used for Static Security Guard.
- `mobile-patrol.png` — supplied patrol image used on the homepage, service
  card and operations panel.
- `cctv-monitoring.png` — supplied CCTV image used for CCTV and
  tracking/monitoring previews.
- `entrance-security.png` — supplied entrance-guard image used in Security
  Personnel operations.
- `operations-team.png` — supplied team image used in the Security Team
  Briefing panel.
- `mobile-escort.png` — supplied close-protection image used for Mobile Escort
  Services.
- `industrial-security.png` — supplied warehouse-inspection image used for
  Security and Safety Equipment and Security Risk Assessment.
- `kuala-lumpur-skyline.png` — supplied Kuala Lumpur skyline used in the About
  section on the homepage and About page.

Supplied personnel images should not be presented as verified photographs of
Bravo staff or client sites unless the company confirms their details. Do not
alter faces in supplied photographs. The Armed Guard image includes a firearm;
use it only if it accurately represents an authorized service.

## Images still needed

Save approved, optimized images to this directory. CSS placeholders remain
functional when an optional image has not yet been added.

| Filename | Use | Priority |
|---|---|---|
| `bodyguard.webp` | Bodyguard / Close Protection service | High |
| `event-security.webp` | Optional photo for event-security operations | Low |

Use landscape compositions for service and operations images (16:9, around
1600 × 900 px). WebP is preferred for newly generated images. Keep faces and
important details near the center to accommodate responsive `object-fit:
cover` crops. The current Services page does not contain a separate operations
gallery, so gallery-specific images are not needed unless that section is
added later.

## Ready-to-use generation prompts

Keep future photographs consistent: photorealistic Malaysian corporate
photography, natural light, restrained red-and-black grading, and the supplied
uniform reference as a visual guide. For newly generated guards, depict diverse
fictional Malaysian men with varied facial features, hairstyles and ages. Do
not invent logos, readable badges, company names, signage or watermarks. There
is no image-generation tool available in this workspace; these prompts are for
later use.

- **`bodyguard.webp`:** Photorealistic Malaysian corporate security
  photography, a discreet fictional Malaysian male close-protection
  professional accompanying a business executive outside a modern office.
  Composed expressions, professional white security shirt and dark trousers,
  no confrontation or tactical action, no logos or readable text. Landscape
  16:9, 1600 × 900 px.
- **`event-security.webp`:** Optional calm security coverage at a Malaysian
  corporate event entrance, fictional Malaysian male security personnel
  monitoring guest arrival, blank or indistinct signs, no logos or readable
  text. Landscape 16:9, 1600 × 900 px.
The homepage hero is eager-loaded at high priority; other image slots are
lazy-loaded. If responsive variants are prepared, add them via `srcset` and
`sizes` on the existing image elements rather than restructuring the pages.

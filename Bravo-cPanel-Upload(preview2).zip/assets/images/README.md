# Website image assets

The approved desktop hero (`hero-security.png`) and mobile hero
(`hero-security-mobile.png`) are already connected to the homepage and must not
be replaced. The official company logo is separate at `assets/img/` and must
not be recreated.

## Images currently in the project

- `hero-security.png` — approved desktop hero; also used as an illustrative
  static-guard image.
- `hero-security-mobile.png` — approved portrait hero for screens up to 720px.
- `about-team.png` — illustrative team image used in the homepage About section.
- `armed-guard.png` — supplied Armed Guard service image.
- `k9-security.png` — supplied K9 service image.

The personnel images should not be presented as documentary photographs of
Bravo staff unless the company verifies that they depict its actual personnel.
The Armed Guard image includes a firearm; use it only if it accurately
represents an authorized service.

## Image slots still needed

Save approved, optimized images to this directory. The current CSS fallbacks
remain visible when an optional image has not yet been added.

| Filename | Use |
|---|---|
| `mobile-patrol.webp` | Mobile Patrols service card |
| `bodyguard.webp` | Bodyguard / Close Protection service |
| `cctv-monitoring.webp` | CCTV and Tracking/Monitoring service cards |
| `industrial-security.webp` | Equipment, Risk Assessment and Operations panels |
| `training-team.webp` | Operations training panel |
| `operations-gallery-01.webp` | Mobile Escort / patrol operations panel |
| `operations-gallery-02.webp` | Event Security / corporate operations panels |
| `kuala-lumpur-skyline.webp` | Optional cityscape replacement for the About image |

Use landscape compositions for service and operations images (16:9, around
1600 × 900 px). The About cityscape should be 4:3 (around 1600 × 1200 px).
WebP is preferred for these optional images. Keep faces and important details
near the center to accommodate responsive `object-fit: cover` crops.

## Ready-to-use generation prompts

Keep the photographs consistent: photorealistic Malaysian corporate
photography, natural light, restrained red-and-black grading, and the supplied
uniform reference as a visual guide. Do not invent logos, readable badges,
company names, signage or watermarks. There is no image-generation tool
available in this workspace; these prompts are for later use.

- **`mobile-patrol.webp`:** Photorealistic Malaysian security guard beside a
  plain, unbranded patrol vehicle at a commercial property, calm routine patrol,
  landscape 16:9, centered composition, no emergency lights or readable text.
- **`bodyguard.webp`:** Discreet Malaysian close-protection professional
  accompanying a business executive outside a modern office, composed
  expressions, no confrontation or tactical action, landscape 16:9.
- **`cctv-monitoring.webp`:** Security operator monitoring generic,
  indistinct surveillance views in a realistic Malaysian control room; no
  readable screens, interface text or logos, landscape 16:9.
- **`industrial-security.webp`:** Security personnel observing a clean
  Malaysian industrial or logistics facility, ordinary safe operations, no
  readable signage or invented equipment claims, landscape 16:9.
- **`training-team.webp`:** Small team of Malaysian security personnel
  attending a professional briefing in a simple training room, no readable
  writing or company marks, landscape 16:9.
- **`operations-gallery-01.webp`:** Routine mobile security escort at a
  Malaysian commercial property, one unbranded vehicle and uniformed personnel,
  no convoy or emergency scene, landscape 16:9.
- **`operations-gallery-02.webp`:** Calm security coverage at a Malaysian
  corporate event entrance, uniformed personnel monitoring guest arrival,
  blank or indistinct signs, landscape 16:9.
- **`kuala-lumpur-skyline.webp`:** Photorealistic Kuala Lumpur skyline at
  warm late-afternoon light, recognizable city towers in a clean corporate
  composition, no text or watermarks, landscape 4:3.

The homepage hero is eager-loaded at high priority; other image slots are
lazy-loaded. If responsive variants are prepared, add them via `srcset` and
`sizes` on the existing image elements rather than restructuring the pages.

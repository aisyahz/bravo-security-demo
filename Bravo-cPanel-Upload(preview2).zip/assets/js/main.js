/* Bravo Security Network website interactions. */
(function () {
  "use strict";

  var header = document.getElementById("siteHeader");
  var toggle = document.getElementById("navToggle");
  var menu = document.getElementById("navMenu");
  var intro = document.getElementById("siteIntro");
  var skipIntro = document.getElementById("skipIntro");

  function closeMenu() {
    if (!toggle || !menu) return;
    menu.classList.remove("open");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open menu");
  }

  if (toggle && menu) {
    toggle.addEventListener("click", function () {
      var isOpen = menu.classList.toggle("open");
      toggle.setAttribute("aria-expanded", isOpen ? "true" : "false");
      toggle.setAttribute("aria-label", isOpen ? "Close menu" : "Open menu");
    });
    menu.addEventListener("click", function (event) {
      if (event.target.closest("a")) closeMenu();
    });
    document.addEventListener("keydown", function (event) {
      if (event.key === "Escape" && menu.classList.contains("open")) {
        closeMenu();
        toggle.focus();
      }
    });
    document.addEventListener("pointerdown", function (event) {
      if (menu.classList.contains("open") &&
          !menu.contains(event.target) &&
          !toggle.contains(event.target)) {
        closeMenu();
      }
    });
  }

  function startWelcomeIntro() {
    if (!intro || !document.querySelector(".hero--home")) return;
    var reduceIntroMotion = window.matchMedia &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceIntroMotion) return;

    try {
      if (window.sessionStorage.getItem("bravoIntroSeen") === "1") return;
      window.sessionStorage.setItem("bravoIntroSeen", "1");
    } catch (error) {
      console.warn("Welcome intro will not be remembered for this browser session.", error);
    }

    var pageRegions = document.querySelectorAll(".site-header, main, .footer, .wa-float");
    pageRegions.forEach(function (region) { region.inert = true; });
    intro.hidden = false;
    document.body.classList.add("intro-active");

    var finished = false;
    function finishIntro() {
      if (finished) return;
      finished = true;
      intro.classList.add("is-leaving");
      window.setTimeout(function () {
        intro.hidden = true;
        intro.classList.remove("is-leaving");
        document.body.classList.remove("intro-active");
        pageRegions.forEach(function (region) { region.inert = false; });
      }, 700);
    }

    if (skipIntro) skipIntro.addEventListener("click", finishIntro, { once: true });
    window.setTimeout(finishIntro, 2100);
  }

  function updateHeader() {
    if (header) header.classList.toggle("scrolled", window.scrollY > 20);
  }
  window.addEventListener("scroll", updateHeader, { passive: true });

  var reduceMotion = window.matchMedia &&
    window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var revealItems = document.querySelectorAll(
    ".section, .operation-card, .service-card, .card, .feature, .vision-card, " +
    ".coverage, .cta-panel, .contact__info, .contact__form, .about__visual"
  );
  if ("IntersectionObserver" in window && !reduceMotion) {
    document.documentElement.classList.add("motion-ready");
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealItems.forEach(function (item) {
      item.classList.add("reveal");
      observer.observe(item);
    });
  }

  var serviceImages = {
    "static-security-guard": ["hero-security.png", "Illustrative security personnel at a commercial entrance"],
    "armed-guard": ["armed-guard.png", "Security guard in tactical equipment at a building entrance"],
    "k9-guard-dog": ["k9-security.png", "Illustrative K9 security service image"],
    "mobile-patrols": ["mobile-patrol.webp", "Illustrative mobile patrol service image"],
    "security-safety-equipment": ["industrial-security.webp", "Illustrative security equipment service image"],
    "bodyguard-close-protection": ["bodyguard.webp", "Illustrative close protection service image"],
    "mobile-escort-services": ["operations-gallery-01.webp", "Illustrative mobile escort service image"],
    "tracking-monitoring-systems": ["cctv-monitoring.webp", "Illustrative tracking and monitoring service image"],
    "cctv-monitoring": ["cctv-monitoring.webp", "Illustrative CCTV monitoring service image"],
    "security-risk-assessment": ["industrial-security.webp", "Illustrative security risk assessment service image"],
    "event-security-management": ["operations-gallery-02.webp", "Illustrative event security service image"],
    "cash-in-transit": ["mobile-patrol.webp", "Illustrative cash in transit service image"]
  };
  Object.keys(serviceImages).forEach(function (id) {
    var card = document.getElementById(id);
    if (!card || card.querySelector(".service-card__media")) return;
    var image = document.createElement("img");
    image.className = "optional-image";
    image.src = "assets/images/" + serviceImages[id][0];
    image.alt = serviceImages[id][1];
    image.loading = "lazy";
    image.decoding = "async";
    image.sizes = "(max-width: 720px) 100vw, 50vw";
    var media = document.createElement("div");
    media.className = "service-card__media";
    media.appendChild(image);
    var icon = card.querySelector(".service-card__icon");
    if (icon) icon.insertAdjacentElement("afterend", media);
    else card.insertAdjacentElement("afterbegin", media);
  });

  document.querySelectorAll(".optional-image").forEach(function (image) {
    var frame = image.parentElement;
    if (!frame) return;
    frame.classList.add("image-frame");
    function setMissing() {
      frame.classList.add("image-missing");
      image.setAttribute("aria-hidden", "true");
    }
    function setLoaded() {
      frame.classList.add("image-loaded");
      frame.classList.remove("image-missing");
      image.removeAttribute("aria-hidden");
    }
    image.addEventListener("error", setMissing, { once: true });
    image.addEventListener("load", setLoaded, { once: true });
    if (image.complete) {
      if (image.naturalWidth > 0) setLoaded();
      else setMissing();
    }
  });

  var floatingWhatsApp = document.querySelector(".wa-float");
  if (floatingWhatsApp && "IntersectionObserver" in window) {
    var overlappingSections = new Set();
    var whatsappObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) overlappingSections.add(entry.target);
        else overlappingSections.delete(entry.target);
      });
      floatingWhatsApp.classList.toggle("is-obscured", overlappingSections.size > 0);
    }, { threshold: 0.08 });
    document.querySelectorAll(".contact__form, .cta-panel, .footer").forEach(function (section) {
      whatsappObserver.observe(section);
    });
  }

  var year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  startWelcomeIntro();
  updateHeader();
})();
